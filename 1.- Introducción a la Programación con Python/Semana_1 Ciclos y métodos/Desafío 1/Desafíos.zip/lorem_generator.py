
texto = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et sagittis sem. Praesent dignissim fringilla nunc vel congue. Sed ultrices maximus orci auctor pharetra. Aenean pellentesque malesuada nisl a malesuada. Nulla mollis scelerisque bibendum. Donec aliquam in elit eget congue. Sed ut pulvinar neque. Nam sed ligula in lectus elementum posuere. Nam venenatis porta posuere. Aliquam vitae scelerisque risus. Quisque dictum diam quis nunc pharetra pellentesque. Cras sed pellentesque metus, a dictum est."
lista = []
parrafos = int(input("Ingrese n° de párrafos\n"))
for i in range(parrafos):
    lista.append(texto)
    print(f"{lista[0]}\n")
